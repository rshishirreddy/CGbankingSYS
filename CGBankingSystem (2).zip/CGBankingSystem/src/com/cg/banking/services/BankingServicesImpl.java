package com.cg.banking.services;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
public class BankingServicesImpl implements BankingServices {
	private BankingDAOServicesImpl bankingDaoServices;
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
		return bankingDaoServices.insertCustomer(new Customer(firstName, lastName, emailId, panCard, new Address(localAddressPinCode, localAddressCity, localAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	}
	@Override
	public long openAccount(int customerId, String accountType, float initBalance) {

		return bankingDaoServices.insertAccount(customerId, new Account(accountType, initBalance));
	}
	@Override
	public float depositAmount(int customerId, long accountNo, float amount) {
		bankingDaoServices.getAccount(customerId, accountNo).setAccountBalance( bankingDaoServices.getAccount(customerId, accountNo).getAccountBalance()+amount);
		bankingDaoServices.insertTransaction(customerId, accountNo, new Transaction(amount, "Deposit"));
		return  bankingDaoServices.getAccount(customerId, accountNo).getAccountBalance();
	}
	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber) {
		while(bankingDaoServices.getAccount(customerId, accountNo).getPinCounter()<3){
			if(bankingDaoServices.getAccount(customerId, accountNo).getPinNumber()==pinNumber)
				if(bankingDaoServices.getAccount(customerId, accountNo).getAccountBalance()-amount>0){
					bankingDaoServices.getAccount(customerId, accountNo).setAccountBalance(bankingDaoServices.getAccount(customerId, accountNo).getAccountBalance()-amount);
					bankingDaoServices.insertTransaction(customerId, accountNo, new Transaction(amount, "Withdrawl"));
					return bankingDaoServices.getAccount(customerId, accountNo).getAccountBalance();
				}
				else
					bankingDaoServices.getAccount(customerId, accountNo).setPinCounter(bankingDaoServices.getAccount(customerId, accountNo).getPinCounter()+1);
		}
		return -1;
	}
	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) {
		float a=this.withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
		if(a==-1){
			this.depositAmount(customerIdTo, accountNoTo, transferAmount);
			return true;
		}else
		return false;
	}
	@Override
	public Customer getCustomerDetails(int customerId) {
		return bankingDaoServices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) {

		return bankingDaoServices.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo) {
		return bankingDaoServices.generatePin(customerId, bankingDaoServices.getAccount(customerId, accountNo));
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber) {
		if(bankingDaoServices.getAccount(customerId, accountNo).getPinNumber()==oldPinNumber){
			bankingDaoServices.getAccount(customerId, accountNo).setPinNumber(newPinNumber);
			return true;
		}
		return false;
	}

	@Override
	public Customer[] getAllCustomerDetails() {

		return bankingDaoServices.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId) {

		return bankingDaoServices.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo) {

		return bankingDaoServices.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo) {

		return bankingDaoServices.getAccount(customerId, accountNo).getStatus();
	}

}
